# one-tg-bot
Telegram → Vercel → Cloudflare Workers entegrasyonu.
Env: BOT_TOKEN, WORKER_URL
Webhook:
https://api.telegram.org/bot<BOT_TOKEN>/setWebhook?url=https://<VERCEL_APP>.vercel.app
